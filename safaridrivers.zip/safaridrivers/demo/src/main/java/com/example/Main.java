package com.example;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.safari.SafariDriver;

public class Main {
    public static void main(String[] args) throws Exception {
        System.out.println("Hello, World!");
        openSafariBrowser();
    }

    public static void openSafariBrowser() {
        // Create a new instance of the Safari driver
        WebDriver driver = new SafariDriver();

        // Open a website
        driver.get("https://www.google.com");

        // Print the title of the page
        System.out.println("Page title is: " + driver.getTitle());

        // Close the browser
        // driver.quit();
    }
}